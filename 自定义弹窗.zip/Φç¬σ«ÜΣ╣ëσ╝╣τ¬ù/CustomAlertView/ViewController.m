//
//  ViewController.m
//  滑动解锁
//
//  Created by mac on 2021/1/20.
//

#import "ViewController.h"
#define ScreenWidth     ([[UIScreen mainScreen] bounds].size.width)
#define ScreenHeight    ([[UIScreen mainScreen] bounds].size.height)
#define ScaleW(width)  width*ScreenWidth/375

#import "CustomAlertView.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   
    
    
    
    
    
}

- (IBAction)loginBtnClick:(UIButton *)sender {
    
//    [CustomAlertView showAlertView_Type:AlertType_Top :ContentType_ContentView];
//    [CustomAlertView showAlertView_Type:AlertType_Meddle :ContentType_ContentView];
    [CustomAlertView showAlertView_Type:AlertType_Bottom :ContentType_ContentView];
}





@end
