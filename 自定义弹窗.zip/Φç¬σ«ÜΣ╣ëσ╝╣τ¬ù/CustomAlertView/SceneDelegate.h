//
//  SceneDelegate.h
//  滑动解锁
//
//  Created by mac on 2021/1/20.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

