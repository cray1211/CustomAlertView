#import <UIKit/UIKit.h>
#import "CustomContentView.h"
#import "UIColor+Extension.h"
#import "UIView+Extensionss.h"
NS_ASSUME_NONNULL_BEGIN
typedef enum : NSUInteger {
    AlertType_Top = 0,
    AlertType_Meddle,
    AlertType_Bottom,
} AlertType;
typedef enum : NSUInteger {
    ContentType_ContentView = 0,
   
} ContentType;
@interface CustomAlertView : UIView
@property (nonatomic ,strong) CustomContentView *mytestContentView;

+(instancetype) showAlertView_Type:(AlertType)showType :(ContentType)contentType;
@property (nonatomic ,strong) void (^cancleCallback)(void);
@property (nonatomic ,assign) UIEdgeInsets alertInset;
@end
NS_ASSUME_NONNULL_END
