//
//  CustomContentView.m
//  CustomAlertView
//
//  Created by mac on 2021/1/23.
//

#import "CustomContentView.h"
#import "Masonry.h"
@interface CustomContentView()

@property (nonatomic ,strong) UIView *bgView;
@property (nonatomic ,strong) UIButton *closeBtn;

@end




@implementation CustomContentView

- (instancetype)init
{
    self = [super init];
    if (self) {
        [self addChildrenViews];
    }
    return self;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self addChildrenViews];
    }
    return self;
}



- (void) addChildrenViews{
    [super addChildrenViews];
    
    [self addSubview:self.bgView];
    [self.bgView addSubview:self.closeBtn];
    self.closeBtn.backgroundColor = UIColor.redColor;
    [self.closeBtn setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
}

- (void)layoutSubviews{
    [super layoutSubviews];
    
    [self.bgView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.right.bottom.mas_equalTo(self);
        make.height.mas_equalTo(300);
    }];
    [self.closeBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.bgView);
        make.left.mas_equalTo(self.bgView).offset(20);
        make.right.mas_equalTo(self.bgView).offset(-20);
        make.height.mas_equalTo(50);
    }];
    
}




- (void) btnclick{
    !self.cancleBtnClick ? : self.cancleBtnClick(self.closeBtn);
}





- (UIButton *)closeBtn{
    if (!_closeBtn) {
        _closeBtn = [[UIButton alloc] init];
        [_closeBtn setTitle:@"关闭" forState:UIControlStateNormal];
        [_closeBtn setTitleColor:UIColor.blueColor forState:UIControlStateNormal];
        [_closeBtn addTarget:self action:@selector(btnclick) forControlEvents:UIControlEventTouchUpInside];
    }
    return _closeBtn;
}

- (UIView *)bgView{
    if (!_bgView) {
        _bgView = [[UIView alloc] init];
        _bgView.backgroundColor = UIColor.orangeColor;
    }
    return _bgView;
}

@end
