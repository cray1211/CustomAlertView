//
//  CustomContentView.h
//  CustomAlertView
//
//  Created by mac on 2021/1/23.
//

#import <UIKit/UIKit.h>
#import "BaseCustomContentView.h"
NS_ASSUME_NONNULL_BEGIN

@interface CustomContentView : BaseCustomContentView
@end

NS_ASSUME_NONNULL_END
